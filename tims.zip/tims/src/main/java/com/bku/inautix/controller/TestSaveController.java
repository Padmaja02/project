package com.bku.inautix.controller;


import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bku.inautix.dao.impl.TestSaveDAOImpl;
import java.sql.Date;

@RestController
@RequestMapping(value = "/testsave")
public class TestSaveController {

	@Autowired
	TestSaveDAOImpl testSaveDAOImpl;

	// StockDAOImpl stockDAOImpl;

	@RequestMapping("view2/{resource_id}/{resource_name}/{technology}/{role}/{areaofinterest}/{experience_summary}/{doj_group}/{end_group}/{doj_inautix}")
	public void getLogin(@PathVariable("resource_id") int resource_id,
			@PathVariable("resource_name") String resource_name,
			@PathVariable("technology") String technology,
			@PathVariable("role") String role,
			@PathVariable("areaofinterest") String areaofinterest,
			@PathVariable("experience_summary") String experience_summary,
			@PathVariable("doj_group") Date doj_group,
			@PathVariable("end_group") Date end_group,
			@PathVariable("doj_inautix") Date doj_inautix, Model model) {
		/*
		 * AdminBean adminbean = AdminDAOImpl.adminLoginRequest(email_id,
		 * password); model.addAttribute("employees",adminbean);
		 */
		testSaveDAOImpl.getInsert(resource_id,resource_name,technology,role,areaofinterest,experience_summary,doj_group,end_group,doj_inautix);

	}

}
