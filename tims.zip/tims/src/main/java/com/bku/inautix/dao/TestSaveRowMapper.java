package com.bku.inautix.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.TestSaveBean;

public class TestSaveRowMapper implements RowMapper<TestSaveBean> {
	public TestSaveBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		TestSaveBean obj = new TestSaveBean();

		obj.setResource_id(rs.getInt("resource_id"));
		obj.setResource_name(rs.getString("resource_name"));
		obj.setTechnology(rs.getString("technology"));
        obj.setRole(rs.getString("role"));
        obj.setAreaofinterest(rs.getString("areaofinterest"));
        obj.setExperience_summary(rs.getString("experience_summary"));
		obj.setDoj_group(rs.getDate("doj_group"));
		obj.setEnd_group(rs.getDate("end_group"));
		obj.setDoj_inautix(rs.getDate("doj_inautix"));

		return obj;

	}

}
