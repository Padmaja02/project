package com.bku.inautix.controller;
import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bku.inautix.dao.impl.TestGroupDAOImpl;
import java.sql.Date;

public class TestGroupController {
	
	
	@RestController
	@RequestMapping(value = "/testgroup")
	public class TestSaveController {

		@Autowired
		TestGroupDAOImpl testGroupDAOImpl;

		// StockDAOImpl stockDAOImpl;

		@RequestMapping("view2/{group_name}/{app_owner}/{group_desc}")
		public void getLogin(@PathVariable("group_name") String group_name,
				@PathVariable("app_owner") String app_owner,
				@PathVariable("group_desc") String group_desc) {
			/*
			 * AdminBean adminbean = AdminDAOImpl.adminLoginRequest(email_id,
			 * password); model.addAttribute("employees",adminbean);
			 */
			testGroupDAOImpl.getInsert(group_name,app_owner,group_desc);

		}

	}

}
