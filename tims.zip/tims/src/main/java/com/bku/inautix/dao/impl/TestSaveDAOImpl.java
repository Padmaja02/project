  package com.bku.inautix.dao.impl;

import java.awt.List;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.PathVariable;

public class TestSaveDAOImpl {

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	
	private HttpServletRequest request;

	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public void getInsert(@PathVariable("resource_id") int resource_id,
			@PathVariable("resource_name") String resource_name,
			
			@PathVariable("technology")String technology,
			@PathVariable("role")String role,
			@PathVariable("areaofinterest")String areaofinterest,
			@PathVariable("experience_summary")String experience_summary,
			@PathVariable("doj_group") Date doj_group,
			@PathVariable("end_group")Date end_group,
			@PathVariable("doj_inautix")Date doj_inautix)
	{
    String res_id=Integer.toString(resource_id);
    DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
    String dateofjoin = df.format(doj_group);
    String endgroup = df.format(end_group);
    String dateinautix = df.format(doj_inautix);
		ArrayList<String> par = new ArrayList<String>();
		par.add(res_id);
		par.add(resource_name);
		par.add(technology);
		par.add(role);
		par.add(areaofinterest);
		par.add(experience_summary);
		par.add(dateofjoin);
		par.add(endgroup);
		par.add(dateinautix);
		
		
		
		JSONObject json = new JSONObject();
        try {
			json.accumulate("details", par);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
        String toinsert = json.toString();
		
	/*	try {
			int[] types = new int[] { Types.INTEGER, Types.VARCHAR,
					Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,Types.VARCHAR,Types.DATE,Types.DATE,Types.DATE };
  
			int i = jdbcTemplate
					.update("insert into T_RESOURCE_DET(resource_id,resource_name,technology,role,areaofinterest,experience_summary,doj_group,end_group,doj_inautix) VALUES(?,?,?,?,?,?,?,?,?)",
							new Object[] { resource_id,resource_name,technology,role,areaofinterest,experience_summary,doj_group,end_group,doj_inautix }, types); // in
																	// parameters

			if (i != 0) {
				System.out.println("Inserted successfully");
			}
		} catch (Throwable fault) {
			System.out.println("Error 404 not found");
			fault.printStackTrace();

		}  */
        
    	try {
			int[] types = new int[] {  Types.VARCHAR };
  
			int i = jdbcTemplate
					.update("insert into res(resource) VALUES(?)",
							new Object[] { toinsert }, types); // in
																	// parameters

			if (i != 0) {
				System.out.println("Inserted successfully");
			}
		} catch (Throwable fault) {
			System.out.println("Error 404 not found");
			fault.printStackTrace();

		}

	}

}
