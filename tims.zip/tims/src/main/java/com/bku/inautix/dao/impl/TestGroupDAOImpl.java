package com.bku.inautix.dao.impl;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Types;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.PathVariable;

public class TestGroupDAOImpl {
	 

	  

	

	  	private DataSource dataSource1;
	  	private JdbcTemplate jdbcTemplate;
	  	
	  	private HttpServletRequest request;

	  	public DataSource getDataSource1() {
	  		return dataSource1;
	  	}

	  	public void setDataSource1(DataSource dataSource1) {
	  		this.dataSource1 = dataSource1;
	  		jdbcTemplate = new JdbcTemplate(dataSource1);
	  	}

	  	public void getInsert(@PathVariable("group_name") String group_name,
	  			@PathVariable("app_owner") String app_owner,
	  			
	  			@PathVariable("group_desc")String group_desc)
	  	{

	  		try {
	  			int[] types = new int[] {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR};

	  			int i = jdbcTemplate
	  					.update("insert into T_GROUP_DET(group_name,app_owner,group_desc) VALUES(?,?,?)",
	  							new Object[] { group_name,app_owner,group_desc}, types); // in
	  																	// parameters

	  			if (i != 0) {
	  				System.out.println("Inserted successfully");
	  			}
	  		} catch (Throwable fault) {
	  			System.out.println("Error 404 not found");
	  			fault.printStackTrace();

	  		}

	  	}

	  }

