package com.bku.inautix.model;
import java.sql.Timestamp;
import java.sql.Date;
public class TestGroupBean {
	
	

		
		private String group_name;
		private String app_owner;
		private String group_desc;
		public String getGroup_name() {
			return group_name;
		}
		public void setGroup_name(String group_name) {
			this.group_name = group_name;
		}
		public String getApp_owner() {
			return app_owner;
		}
		public void setApp_owner(String app_owner) {
			this.app_owner = app_owner;
		}
		public String getGroup_desc() {
			return group_desc;
		}
		public void setGroup_desc(String group_desc) {
			this.group_desc = group_desc;
		}
		
		
		

		

		

	

}
