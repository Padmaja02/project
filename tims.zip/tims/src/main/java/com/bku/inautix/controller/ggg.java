package com.bku.inautix.controller;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.portlet.ModelAndView;

public class Company{
@RequestMapping(value = "/angularjs-http-service-ajax-post-json-data-code-example", method = RequestMethod.GET)
public ModelAndView httpServicePostJSONDataExample( ModelMap model ) {
	return new ModelAndView("httpservice_post_json");
}

@RequestMapping(value = "/savecompany_json", method = RequestMethod.POST)	
public  @ResponseBody String saveCompany_JSON( @RequestBody Company company )   {		
	//
	// Code processing the input parameters
	//	
	return "JSON: The company name: " + company.getName() + ", Employees count: " + company.getEmployees() + ", Headoffice: " + company.getHeadoffice();
}
}