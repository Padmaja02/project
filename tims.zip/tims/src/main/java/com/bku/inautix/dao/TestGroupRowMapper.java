package com.bku.inautix.dao;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bku.inautix.model.TestGroupBean;

	

	public class TestGroupRowMapper implements RowMapper<TestGroupBean> {
		public TestGroupBean mapRow(ResultSet rs, int rowNum) throws SQLException {
			TestGroupBean obj = new TestGroupBean();

			obj.setGroup_name(rs.getString("group_name"));
			obj.setApp_owner(rs.getString("app_owner"));
			obj.setGroup_desc(rs.getString("group_desc"));
	        

			return obj;

		}

	}


