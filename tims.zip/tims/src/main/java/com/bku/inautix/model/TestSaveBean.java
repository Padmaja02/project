package com.bku.inautix.model;

import java.sql.Timestamp;
import java.io.Serializable;
import java.sql.Date;
public class TestSaveBean implements Serializable {

	private int resource_id;
	private String resource_name;
	private String technology;
	private String role;
	private String areaofinterest;
	private String experience_summary;
	private Date doj_group;
	private Date end_group;
	private Date doj_inautix;
	public int getResource_id() {
		return resource_id;
	}
	public void setResource_id(int resource_id) {
		this.resource_id = resource_id;
	}
	public String getResource_name() {
		return resource_name;
	}
	public void setResource_name(String resource_name) {
		this.resource_name = resource_name;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getAreaofinterest() {
		return areaofinterest;
	}
	public void setAreaofinterest(String areaofinterest) {
		this.areaofinterest = areaofinterest;
	}
	public String getExperience_summary() {
		return experience_summary;
	}
	public void setExperience_summary(String experience_summary) {
		this.experience_summary = experience_summary;
	}
	public Date getDoj_group() {
		return doj_group;
	}
	public void setDoj_group(Date doj_group) {
		this.doj_group = doj_group;
	}
	public Date getEnd_group() {
		return end_group;
	}
	public void setEnd_group(Date end_group) {
		this.end_group = end_group;
	}
	public Date getDoj_inautix() {
		return doj_inautix;
	}
	public void setDoj_inautix(Date doj_inautix) {
		this.doj_inautix = doj_inautix;
	}

	

	

}
