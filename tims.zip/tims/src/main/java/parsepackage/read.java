package parsepackage;
import java.io.*;
import java.util.*;

import org.json.simple.*;
import org.json.simple.parser.JSONParser;

public class read {

       public static void main(String[] args) {
               JSONParser parser = new JSONParser();
       
               try {
       
                   Object obj = parser.parse(new FileReader(
                           "http://localhost:8080/tims/show.jsp"));
       
                   JSONObject jsonObject = (JSONObject) obj;
       
                   String id = (String) jsonObject.get("id");
                   String name = (String) jsonObject.get("name");
                   String tech = (String) jsonObject.get("tech");
                   String role = (String) jsonObject.get("role");
                   String area_of_int = (String) jsonObject.get("area_of_int");
                   String summary = (String) jsonObject.get("summary");
                   String start_date = (String) jsonObject.get("start_date");
                   String end_date = (String) jsonObject.get("end_date");
                   String start_inautix_date = (String) jsonObject.get("start_inautix_date");
                   System.out.println("RESOURCE ID: " +id);
                   System.out.println("RESOURCE NAME: " +name);
                   System.out.println("TECHNOLOGY: " +tech);
                   System.out.println("ROLE: " +role);
                   System.out.println("AREA OF INTEREST: " +area_of_int);
                   System.out.println("EXPERIENCE SUMMARY: " +summary);
                   System.out.println("GROUP START DATE: " +start_date);
                   System.out.println("GROUP END DATE: " +end_date);
                   System.out.println("INAUTIX START DATE: " +start_inautix_date);
                   
               } catch (Exception e) {
                   e.printStackTrace();
               }
           }
}
