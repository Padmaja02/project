package com.j2ee;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class data
 */
@WebServlet("/data")
public class data extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   public data()
   {
	   super();
   }
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		PreparedStatement ps;
	      ResultSet rs;
		Connection con;
		PrintWriter out=response.getWriter();
		String name=request.getParameter("t1");
		
		String check[]=request.getParameterValues("c1");
		
		String gender=request.getParameter("r");
		
		try
		{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana"); 
			
			for(int i=0;i<check.length;i++)
			{
			 ps=con.prepareStatement("insert into stupid values(?,?,?)");
			 System.out.println("prepare Statement");	
				
			ps.setString(1,name);
			
			ps.setString(2,check[i]);
			ps.setString(3,gender);
			rs=ps.executeQuery();
			ps.close();
			}
			Statement stat=con.createStatement();
			String s="select * from stupid";
			rs=stat.executeQuery(s);
			if(rs.next())
			{ 
					
				String name1=rs.getString(1);
			out.println(name1);  
			String sub=rs.getString(2);
			out.println(sub);
			String gend=rs.getString(3);
			out.println(gend);
			}  
			
		
		}
		catch(Exception e)
		{
	System.out.println(e);
		}
		
	}

}
