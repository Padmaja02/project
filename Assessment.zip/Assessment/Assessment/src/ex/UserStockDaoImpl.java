package ex;

	import java.sql.*;

	public class UserStockDaoImpl implements UserStockDao {

		Connection con;
		public void getConnection(){
			try{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
				}catch(Exception e){
					e.printStackTrace();
				}
		}
		
			public String insert(String user,String[] company){
				getConnection();
				PreparedStatement ps;
				
				String status="";
				String query="insert into table_xbbl5q7 values(?,?,?)";
				try {
					 String time = ""+(new Timestamp((new java.util.Date()).getTime()));
						
					for(String s:company){
					 ps= con.prepareStatement(query);
					ps.setString(1,s);
					ps.setString(2,time);
					ps.setString(3,user);
					ps.executeUpdate();
					String tab="select * from table_xbbl5q7";
					ps.execute(tab);
					status= time;
					}
				}catch (SQLException e) {
					e.printStackTrace();
				}
				return status;
		}
	}
		
