package ex;

import java.sql.*;
class ConnectOracle {
	public static void main(String [] Args){
		//Load the driver
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
		}catch (java.lang.ClassNotFoundException e) {
			System.out.println(e);
		}
		try {
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
			System.out.println("Connected to Oracle DB");

		DatabaseMetaData dmd = con.getMetaData();
			String prod = dmd.getDatabaseProductName();
		String ver = dmd.getDatabaseProductVersion();

			System.out.println("DB Product : " + prod);
			System.out.println("DB Version : " + ver);
			Statement stmt=con.createStatement();
			String sql="select * from table_xbbl5q7";
			ResultSet rs=stmt.executeQuery(sql);
			while(rs.next())
			{
				System.out.println(rs.getString("COMP_NAME"));
				System.out.println(rs.getString("UPDATE_TIMESTAMP"));
				
			}
			con.close();
		}catch (SQLException e) {
			System.out.println(e);
			System.out.println(e.getMessage());
			System.out.println(e.getSQLState());
			System.out.println(e.getErrorCode());
			e.getNextException();
		}
		
	}

}