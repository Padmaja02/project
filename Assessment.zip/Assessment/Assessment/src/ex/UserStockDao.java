package ex;

public interface UserStockDao {
	public void getConnection();
	public String insert(String user,String[] company);
	
}
