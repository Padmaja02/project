	package ex;

import java.sql.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ex.SpaceFoundException;

/**
 * Servlet implementation class StockController
 */
@WebServlet("/StockController")
public class StockController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StockController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    Connection con=null;
     try
     {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
		
     }catch(Exception e){
			e.printStackTrace();
		}
        PrintWriter out=response.getWriter();
		UserStockDaoImpl us=new UserStockDaoImpl();
		String user=request.getParameter("user");
		String[] space= user.split(" ");
		if(space.length>1){
			try {
				throw new SpaceFoundException();
			} catch (SpaceFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			RequestDispatcher rq=request.getRequestDispatcher("error.jsp");
			rq.forward(request,response);
		}
		else{
		String[] company = request.getParameterValues("c1");
		String status = us.insert(user,company);
	request.setAttribute("time",status);
			request.setAttribute("user",user);
			request.setAttribute("company", company);
		RequestDispatcher rq=request.getRequestDispatcher("success.jsp");
		rq.forward(request,response);
		try
		{
		Statement stmt=con.createStatement();
	ResultSet rs=stmt.executeQuery("select * from table_xbbl5q7");
	while(rs.next())
	{
		String name=rs.getString("COMP_NAME");
		String time=rs.getString("UPDATE_TIMESTAMP");
		out.println("<html><body>"+name+"</body></html>");
	}
		}
		catch(Exception e)
		{}
		
	}
	}

}
