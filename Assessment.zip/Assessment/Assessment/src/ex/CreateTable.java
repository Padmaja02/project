package ex;

import java.sql.*;

class CreateTable {
       public static void main(String args[]) {

              try {
                     Class.forName("oracle.jdbc.driver.OracleDriver");
              }catch(ClassNotFoundException e) {
                     System.out.println(e);
              }
              try {
                     Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
                     SQLWarning w = con.getWarnings();

                     while(w != null) {
                           System.out.println(w.getMessage());
                           System.out.println(w.getSQLState());
                           System.out.println(w.getErrorCode());
                           w = w.getNextWarning();
                     }

                     con.setAutoCommit(false);

                     DatabaseMetaData dbmd = con.getMetaData();

                     System.out.println(dbmd.getDatabaseProductName());
                     System.out.println(dbmd.getDatabaseProductVersion());

                     Statement stmt = con.createStatement();
           stmt.execute("create table table_xbbl5q7 (COMP_NAME varchar(50),UPDATE_TIMESTAMP varchar(50),USER_NAME varchar(50))");

                     con.commit();
                     con.close();

              }catch(SQLException e) {
                     System.out.println(e);
                     System.out.println(e.getMessage());
                     System.out.println(e.getSQLState());
                     System.out.println(e.getErrorCode());
                     e = e.getNextException();
       }

       }
}
