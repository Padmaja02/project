package ex;

public class SpaceFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SpaceFoundException() {
		// TODO Auto-generated constructor stub
	}

	public SpaceFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public SpaceFoundException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public SpaceFoundException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}


}
