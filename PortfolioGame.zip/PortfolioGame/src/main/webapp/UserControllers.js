/**
 * 
 */





var myApp=angular.module('myApp',[]);
var context = localStorage.getItem("context");

myApp.controller('userCtrl',function($scope, $http) {
	
/*	$(document).ready(function(){
	    $('[data-toggle="popover"]').popover();   
	});*/
	
	 $('[data-toggle="popover"]').popover(); 
	$scope.missmatch=false;
	$scope.signupdef=true;
	$scope.logindef=true;
	$scope.getDatetime  = new Date();
	$http.get("/MyRestDB/cxfservlet/jaxrs-server/service/marketPrices/"+$scope.getDatetime)
	.success(function(response) 
		{
			$scope.marketPrice=response.marketPrice;
		});
	
	$http.get("/MyRestDB/cxfservlet/jaxrs-server/service/premarketPrices/"+$scope.getDatetime)
	.success(function(response) 
		{
			$scope.premarketPrice=response.marketPrice;
		});
	
/*	$http.get("/MyRestDB/cxfservlet/jaxrs-server/service/preStocks")
	.success(function(response) 
		{
			$scope.premarketPrice=response.stock;
		});*/

	$http.get("/MyRestDB/cxfservlet/jaxrs-server/service/news/"+$scope.getDatetime,{cache:false})
	.success(function(response) 
		{
			$scope.newson=response.news;
		});


	$http.get("/MyRestDB/cxfservlet/jaxrs-server/service/gamers/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
	.success(function(response) {$scope.gamers=response.gamer;});
	
	$http.get("/MyRestDB/cxfservlet/jaxrs-server/service/losers/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
	.success(function(response) {$scope.gamers1=response.gamer;});
	
/*	$(document).ready(function(){
	    $('[data-toggle="tooltip"]').tooltip();   
	});*/


	$scope.getData = function(data)
	{
		document.getElementById('stockselect').value=data;
	    $http.get("/MyRestDB/cxfservlet/jaxrs-server/service/employee/"+data)
	    .success(function(response)
		{
	    	$scope.price=response.employee.price;
		});
	}

	
	$scope.getEmployee = function() {
	    $http.get("/MyRestDB/cxfservlet/jaxrs-server/commonservice/login/"+$scope.usrname+"/"+$scope.passwd)
		.success(function(response) {
		$scope.employee=response.session; 
		if(response.session.usrname=="2")
			{
			$(document).ready(function(){
			    $(".close").click(function(){
			        $("#myAlert1").alert("close");
			    });
			});
		document.getElementById('n2').innerHTML="UserName and Password mismatch";
		document.getElementById('n2').style.color="red";
		$scope.missmatchlogin=true;
			}
		else if($scope.usrname==response.session.usrname)
		{
			if(response.session.type=='u')
				{
		$scope.flag= false;
		alert("Welcome to Portfolio Game");
		$scope.uname=response.session.name;
		$scope.signupdef=false;
		$scope.logindef=false;
		$scope.logedon=true;
		
		
		$http.get("/MyRestDB/cxfservlet/jaxrs-server/service/holding/"+$scope.usrname+"/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
		.success(function(response) 
			{
				$scope.holdon=response.holding;
			});
		
		$http.get("/MyRestDB/cxfservlet/jaxrs-server/service/holding/"+$scope.usrname+"/"+$scope.getDatetime+"/"+$scope.getDatetime)
		.success(function(response) 
			{
			    
				for(i = 0; i < response.holding.length; i++)
				{
							total += (response.holding[i].amtLG);
			    }
				
				$scope.holdonvalue=total;
					if($scope.holdonvalue < 0)
					{
					document.getElementById("holdons1").style.color="#FF0000";
					document.getElementById("percent").style.color="#FF0000";
					}
				else if($scope.holdonvalue > 0)
					{
					document.getElementById("holdons1").style.color="#00FF00";
					document.getElementById("percent").style.color="#00FF00";
					}
			});
		

		$http.get("/MyRestDB/cxfservlet/jaxrs-server/service/history/"+$scope.usrname+"/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
		.success(function(response)
			{
				$scope.transactions=response.transaction;
			});	
		
		$scope.holdingsBootstrap=true;
		
		/*window.location.replace("/PortfolioGame/user.jsp");*/
				}
			else if(response.session.type=='a')
				{
				$scope.flag= false;
				alert("Welcome Admin");
				
				window.location.replace("/PortfolioGame/admin.jsp");
				}
		}
		});
	    
	    $scope.employees=null;
	};
	
	$scope.all = function() {
	$http.get("/MyRestDB/cxfservlet/jaxrs-server/commonservice/register/"+ $scope.usrname1)
	.success(function(response){
    var n=0;
    if($scope.regusrname==response.session.usrname)
	{
	document.getElementById("n1").innerHTML="Sorry, User name already exist!!! Please try different";
	document.getElementById('n1').style.color="red";
    n=1;	
	}
	if(n==0)
	{	
	if(document.getElementById("passwd1").value == document.getElementById("passwd2").value)
	{
		$http.get("/MyRestDB/cxfservlet/jaxrs-server/commonservice/register/"+ $scope.usrname1+ "/"+ $scope.passwd1+ "/"+ $scope.name1+ "/"+ $scope.email)
    	.success(function(response) {
		$scope.employee=response.session;
		$scope.flag = false;
		document.getElementById('n1').innerHTML="Your username has been created.. Kindly login with your username";
		$scope.usrname1="";
		$scope.passwd1="";
		$scope.name1="";
		$scope.email="";
		$scope.passwd2="";
		$scope.register=false;});  
	
	$scope.flag = false;
	$scope.l1=true;
	$scope.register=false;
	}
	else
	{
		$(document).ready(function(){
		    $(".close").click(function(){
		        $("#myAlert").alert("close");
		    });
		});
	document.getElementById('n1').innerHTML="Password mismatch";
	document.getElementById('n1').style.color="red";
	$scope.missmatch=true;
	}
	}
	});
	};
	
	$scope.hello = function() {
		$scope.register=false;
		$scope.l1=true;		
	    $scope.employees=null;
	    $scope.flag = false;
	    $scope.stocks=false;
	    $scope.admin=false;
	};
	
	$scope.reset = function() {
		$scope.l1=false;
		$scope.register=true;
	    $scope.employees=null;
	    $scope.flag = false;
	};
	
	$http.get("/MyRestDB/cxfservlet/jaxrs-server/service/stocksName")
	.success(function(response) {$scope.stocks=response.stocks;})
	.error(function(response) {$scope.name="error";});
		
	$scope.flag2=false;
	$scope.getStock = function() 
	{
		$scope.flag2=true;
	    $http.get("/MyRestDB/cxfservlet/jaxrs-server/service/employee/"+$scope.name)
	    .success(function(response)
		{
	    	$scope.employee=response.employee;
			 
		});    
	};
		
	$scope.getPrice=function()
	{
		$scope.flag2=true;
	    $http.get("/MyRestDB/cxfservlet/jaxrs-server/service/employee/"+$scope.name)
	    .success(function(response)
		{
	    	$scope.price=response.employee.price;
		});

	}
	
	$scope.trade = function() 
	{
	    $http.get("/MyRestDB/cxfservlet/jaxrs-server/service/employee/"+$scope.chuma)
	    .success(function(response)
		{
	    	$scope.name1=response.employee;
		});
	};

	
	$scope.getDatetime  = new Date();
	$scope.buy = function() 	
	{
		if($scope.quantity==null || $scope.quantity=="")
			{
			document.getElementById('quan').innerHTML="Please Enter Quantity Before You Proceed";
			document.getElementById('quan').style.color="red";
		}
		else
			{
	    $http.get("/MyRestDB/cxfservlet/jaxrs-server/service/employee1/"+$scope.name+"/"+$scope.price+"/"+$scope.getDatetime+"/"+$scope.quantity+"/"+$scope.usrname)
	    .success(function(response)
		{
	    	$scope.sample=response.employee1;
	    	if(response.employee1==null)
	    	{
	    		alert("insufficient balance");
	    	}
	    	else
	    	{
	    		alert("Success,Trade has been bought!!");
	    		
	    		$http.get("/MyRestDB/cxfservlet/jaxrs-server/service/holding/"+$scope.usrname+"/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
	    		.success(function(response) 
	    			{
	    				$scope.holdon=response.holding;
	    			});
	    		
	    		$http.get("/MyRestDB/cxfservlet/jaxrs-server/service/holding/"+$scope.usrname+"/"+$scope.getDatetime+"/"+$scope.getDatetime)
	    		.success(function(response) 
	    			{
	    			    
	    				for(i = 0; i < response.holding.length; i++)
	    				{
	    							total += (response.holding[i].amtLG);
	    			    }
	    				
	    				$scope.holdonvalue=total;
	    					if($scope.holdonvalue < 0)
	    					{
	    					document.getElementById("holdons1").style.color="#FF0000";
	    					document.getElementById("percent").style.color="#FF0000";
	    					}
	    				else if($scope.holdonvalue > 0)
	    					{
	    					document.getElementById("holdons1").style.color="#00FF00";
	    					document.getElementById("percent").style.color="#00FF00";
	    					}
	    			});
	    		
	    		
	    		/*$http.get("/MyRestDB/cxfservlet/jaxrs-server/service/holding/"+$scope.uid+"/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
	    		.success(function(response) 
	    		{
	    			$scope.holdon=response.holding;
	    		});
		
	    		$http.get("/MyRestDB/cxfservlet/jaxrs-server/service/history/"+$scope.uid+"/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
	    		.success(function(response) 
	    		{
	    			$scope.transactions=response.transaction;
	    		});*/
	    	}

		});
			}
	};
	
	$scope.getDatetime  = new Date();
	$http.get("/MyRestDB/cxfservlet/jaxrs-server/service/mosttraded/"+$scope.getDatetime)
	.success(function(response)
		{
			$scope.mosttraded=response.mosttraded;
		});	
	
		
	/*
	 * Selling a stock
	*/
	
	$scope.sell = function() 	
	{
		if($scope.quantity==null || $scope.quantity=="")
		{
		document.getElementById('quan').innerHTML="Please Enter Quantity Before You Proceed";
		document.getElementById('quan').style.color="red";
		}
	else
		{
		$http.get("/MyRestDB/cxfservlet/jaxrs-server/service/employee2/"+$scope.name+"/"+$scope.price+"/"+$scope.getDatetime+"/"+$scope.quantity+"/"+$scope.usrname)
		.success(function(response)
		{
			$scope.sample=response.employee1;  
			if(response.employee1==null)
			{
				alert("Stocks not available");
			}
			else
			{
				alert("Stocks Sell is successfull");
				
				$http.get("/MyRestDB/cxfservlet/jaxrs-server/service/holding/"+$scope.usrname+"/"+$scope.getDatetime+"/"+$scope.getDatetime.getMilliseconds())
				.success(function(response) 
					{
						$scope.holdon=response.holding;
					});
				
				$http.get("/MyRestDB/cxfservlet/jaxrs-server/service/holding/"+$scope.usrname+"/"+$scope.getDatetime+"/"+$scope.getDatetime)
				.success(function(response) 
					{
					    
						for(i = 0; i < response.holding.length; i++)
						{
									total += (response.holding[i].amtLG);
					    }
						
						$scope.holdonvalue=total;
							if($scope.holdonvalue < 0)
							{
							document.getElementById("holdons1").style.color="#FF0000";
							document.getElementById("percent").style.color="#FF0000";
							}
						else if($scope.holdonvalue > 0)
							{
							document.getElementById("holdons1").style.color="#00FF00";
							document.getElementById("percent").style.color="#00FF00";
							}
					});
			}
		});
		}
	};
	
	/*
	 * Log out for users
	*/
		$scope.logout = function()
		{
			$http.get("/MyRestDB/cxfservlet/jaxrs-server/service/logOut")
			.success(function(response) 
					{
						alert("Successfully logged out");
						window.location.replace("/PortfolioGame/indexboot.jsp");
					});
		};
});