package com.tra.dao;
import java.util.List;

import com.tra.model.*;
public interface IEmployeeDao 
{
	public List addEmp(EmpBean empBean);
	public List getAllEmp();
	public List editEmp(EmpBean empBean);
	public List deleteEmp(EmpBean empBean);
}
