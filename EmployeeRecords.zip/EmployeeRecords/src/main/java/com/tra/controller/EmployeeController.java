package com.tra.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.tra.model.*;
import com.tra.daoImpl.*;
@RestController
@RequestMapping(value="/employees")

public class EmployeeController 
{
	@Autowired
	EmployeeDaoImpl daoImpl;
	@RequestMapping(value="/allEmpRecord" , method=RequestMethod.GET)
	public List<EmpBean> getSessionDetails()
	{
		List empList=null;
		empList=daoImpl.getAllEmp();
		return empList;
	}
	@RequestMapping(value="/addEmpRecord" , method=RequestMethod.POST)
	public List<EmpBean> addEmpRecord(@RequestBody EmpBean empBean)
	{
		List empList=null;
		empList=daoImpl.addEmp(empBean);
		return empList;
	}
	@RequestMapping(value="/editEmpRecord" , method=RequestMethod.PUT)
	public List<EmpBean> editEmpRecord(@RequestBody EmpBean empBean)
	{
		List empList=null;
		empList=daoImpl.editEmp(empBean);
		return empList;
	}
	@RequestMapping(value="/deleteEmpRecord" , method=RequestMethod.DELETE)
	public List<EmpBean> deleteEmpRecord(@RequestBody EmpBean empBean)
	{
		List empList=null;
		empList=daoImpl.deleteEmp(empBean);
		return empList;
	}

}
