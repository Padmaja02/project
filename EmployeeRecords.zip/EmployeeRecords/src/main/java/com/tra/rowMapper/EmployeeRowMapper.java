package com.tra.rowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;
import com.tra.model.*;
public class EmployeeRowMapper implements RowMapper<EmpBean> 

{

	public EmpBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		EmpBean empBean =new EmpBean();
		empBean.setEmpId(rs.getString("empId"));
		
		empBean.setEmpName(rs.getString("empName"));
		empBean.setDob(rs.getString("dob"));
		empBean.setDesignation(rs.getString("designation"));
		return empBean;
	}
	
}
