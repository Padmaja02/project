package com.tra.daoImpl;

import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.support.DaoSupport;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;





import com.tra.dao.IEmployeeDao;
import com.tra.model.EmpBean;
import com.tra.rowMapper.*;

@Component
public class EmployeeDaoImpl extends JdbcDaoSupport  implements IEmployeeDao 
{
	@Autowired
	public EmployeeDaoImpl(DataSource dataSource)
	{
		setDataSource(dataSource);
	}


	public List addEmp(EmpBean empBean) {
		List <EmpBean> empList=null;
		int n=0;
		try
		{
			n=getJdbcTemplate().update("insert into T_XBBL5RG_EMPREC values (?,?,?,?)", new Object[]{empBean.getEmpId(),empBean.getEmpName(),empBean.getDob(),empBean.getDesignation()}, new int [] {Types.VARCHAR,Types.VARCHAR,Types.DATE,Types.VARCHAR});
		}
		catch(Exception e)
		{
			System.out.println("Exception caught");
			List errorList=new ArrayList();
			String error="There is problem inserting values, try changing the empId & values";
			errorList.add(error);
			return errorList;
		}
		if(n>0)
		{
			empList=getJdbcTemplate().query("select * from T_XBBL5RG_EMPREC ", new Object []{}, new EmployeeRowMapper());
			return empList;
		}
		else
			return null;
	}

	public List getAllEmp() {
		List <EmpBean> empList=null;
		empList=getJdbcTemplate().query("select * from T_XBBL5RG_EMPREC ", new Object []{}, new EmployeeRowMapper());

		return empList;
	}


	public List editEmp(EmpBean empBean) {
		List <EmpBean> empList=null;
		
		int n=0;
		try
		{
			n=getJdbcTemplate().update("update T_XBBL5RG_EMPREC set empName=?,dob=?,designation=? where empId=?", new Object[]{empBean.getEmpName(),empBean.getDob(),empBean.getDesignation(),empBean.getEmpId()}, new int [] {Types.VARCHAR,Types.DATE,Types.VARCHAR,Types.VARCHAR});
		}
		catch(Exception e)
		{
			System.out.println("Exception caught");
			List errorList=new ArrayList();
			String error="There is problem updating values, try changing the empId & values";
			errorList.add(error);
			return errorList;
		}
		if(n>0)
		{
			empList=getJdbcTemplate().query("select * from T_XBBL5RG_EMPREC ", new Object []{}, new EmployeeRowMapper());
			return empList;
		}
		else
			return null;
	}


	public List deleteEmp(EmpBean empBean) {
List <EmpBean> empList=null;
		
		int n=0;
		try
		{
			n=getJdbcTemplate().update("delete from T_XBBL5RG_EMPREC where empId=?", new Object[]{empBean.getEmpId()}, new int [] {Types.VARCHAR});
		}
		catch(Exception e)
		{
			System.out.println("Exception caught");
			List errorList=new ArrayList();
			String error="There is problem deleting values, try changing the empId & values";
			errorList.add(error);
			return errorList;
		}
		if(n>0)
		{
			empList=getJdbcTemplate().query("select * from T_XBBL5RG_EMPREC ", new Object []{}, new EmployeeRowMapper());
			return empList;
		}
		else
			return null;
	}
	
}
