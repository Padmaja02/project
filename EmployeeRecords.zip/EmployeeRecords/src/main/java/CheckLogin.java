
import com.tra.model.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import com.google.gson.Gson;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class CheckLogin
 */
public class CheckLogin extends HttpServlet{
	private static final long serialVersionUID = 1L;
	public String id="";
	public String designation="";
   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	
	 
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String uname=request.getParameter("uname");
		String pass=request.getParameter("pass");
		
		boolean status=false;  
		
		try
		{  
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
			
			PreparedStatement ps=con.prepareStatement("select * from T_XBBL5RG_EMPREC where empName=? and empId=?");  
			ps.setString(1,uname);  
			ps.setString(2,pass);  
			      
			ResultSet rs=ps.executeQuery();
			
			status=rs.next();
			
			
			if(status)
			{
				
				ps=con.prepareStatement("select * from T_XBBL5RG_EMPREC where empId=?");
				ps.setString(1,pass);
				rs=ps.executeQuery();
				int i=0;
				while(rs.next())
				{
					designation=rs.getString("designation");
				}
				EmpBean eBean = new EmpBean();
				eBean.setEmpId(designation);
				String empJson = new Gson().toJson(eBean);
				
				//response.setContentType("application/json");
	            response.getWriter().write(empJson);
	           // out.print(empJson);
	          //  out.flush();
	            request.setAttribute("designation", designation);
	            
				RequestDispatcher rd=request.getRequestDispatcher("addEmployee.jsp?designation="+designation);
				rd.forward(request, response);
				//out.flush();
			}
			else
			{
				out.println("Wrong Credentials !!");
				RequestDispatcher rd= request.getRequestDispatcher("index.jsp");
				rd.include(request, response);
			}

			
			
		}
		catch(Exception e)
		{
			System.out.println("Found a Exception");
			System.out.println(e);
		}

		
		
		
		
	}

}
