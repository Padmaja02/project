package com.j2ee;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;


public class UserAccount {
	//private static String num="00000000";
	private final String value="HDFC";

    public String initialize(String str) {
                    // TODO Auto-generated method stub
                    	String currentacc="";
                    
                    	//String num1=str.substring(8);
                    	long num2=Long.parseLong(str);
                    	System.out.println(str);
                    	num2=num2+1;
                        String newaccno = String.valueOf(num2);
                        System.out.println(newaccno);
                        if (newaccno.length() < 8) {
                               for (int i = 0; i < (8 - newaccno.length()); i++) {
                                      currentacc = currentacc + "0";
                               }
                        }
                    	StringBuilder sb=new StringBuilder();
                    	int year = Calendar.getInstance().get(Calendar.YEAR);
                    	sb=sb.append(value).append(year).append(currentacc).append(newaccno);
                    	System.out.println(sb);
                    	String op=sb.toString();
                    	
                    	return op  ;
                                                    
   }
}

