package com.j2ee;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bank.bean.CustomerBean;

/**
 * Servlet implementation class FundController
 */
@WebServlet("/FundTransfer")
public class FundController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name=request.getParameter("t1");
		String acc=request.getParameter("t2");
		int amount=Integer.parseInt(request.getParameter("t4"));
		int amtbank=CustomerBean.getAmount();
		String accountno=CustomerBean.getAccountnumber();
		int amounttransfer=0;
		int amounttransfer1=0;
		int amtpayee=0;
		 try {
			 Connection con;
				
			      ResultSet rs;
			      HttpSession session=request.getSession(); 
	Class.forName("oracle.jdbc.driver.OracleDriver");
	con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
	Statement s=con.createStatement();	 
	String query="select * from users_bank";
		 rs=s.executeQuery(query);
		 while(rs.next())
		 {
			 String username=rs.getString("username");
			 String accno=rs.getString("accountnumber");
			 String payee="select amount from users_bank where accountnumber='"+accno+"'";
			 rs=s.executeQuery(payee);
			 while(rs.next())
			 {
				 amtpayee=rs.getInt(1);
			 }
			if(name.equals(username) && acc.equals(accno)) 
			{
				if(amount < amtbank)
				{
					amounttransfer=amtbank-amount;
					String query1="update users_bank set amount="+amounttransfer+" where accountnumber='"+accountno+"'";
					rs=s.executeQuery(query1);
					System.out.println("Transferred");
					amounttransfer1=amtpayee+amount;
					String query2="update users_bank set amount="+amounttransfer1+" where accountnumber='"+acc+"'";
					rs=s.executeQuery(query2);
					System.out.println("Transfer success");
				}
			}
				String q="select * from users_bank where accountnumber='"+accountno+"'";
				rs=s.executeQuery(q);
				System.out.println("Done");
				while(rs.next())
				{
					CustomerBean.setAmount(rs.getInt("amount"));
					RequestDispatcher rd=request.getRequestDispatcher("Welcome.jsp");
			        rd.forward(request, response);
				}
				  
			
		 }
		 } 
		 catch(Exception e)
	        {
	                        e.printStackTrace();
	        }
	}

}
