package com.j2ee;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.bean.CustomerBean;
/**
 * Servlet implementation class PasswordController
 */
@WebServlet("/PasswordChangeController")
public class PasswordController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				String old_password=request.getParameter("t1");
				System.out.println(old_password);
				String new_password=request.getParameter("t2");
				System.out.println(new_password);
				String accountnumber=CustomerBean.getAccountnumber();
				System.out.println(accountnumber);
				String password_db=CustomerBean.getPassword();
				System.out.println(password_db);
				try
				{
					  Connection con;
					  ResultSet rs;
				      Class.forName("oracle.jdbc.driver.OracleDriver");
				      con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
				      Statement s=con.createStatement();
					if(old_password.equals(password_db))
				{
						System.out.println("block");
				   String query="update users_bank set password='"+new_password+"' where accountnumber='"+accountnumber+"'";
				   rs=s.executeQuery(query);
				   System.out.println("Password changed");
				}
				   String query1="select * from users_bank where accountnumber='"+accountnumber+"'";
				   rs=s.executeQuery(query1);
				   while(rs.next())
				   {
					   CustomerBean.setPassword(rs.getString("password"));
					   RequestDispatcher rd=request.getRequestDispatcher("PasswordSuccess.jsp");
				        rd.forward(request, response);
				   }
				
				}
				catch(Exception e)
				{
					
				}
			}

		}

	


