package com.j2ee;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bank.bean.CustomerBean;


@WebServlet("/Welcome1")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public LoginServlet() {
        super();
        
    }

	 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 Connection con;
			PreparedStatement ps;
		      ResultSet rs;
		      String name=request.getParameter("t1");
		      String pass=request.getParameter("t4");
		      try {
		    	  HttpSession session=request.getSession();     
		    	  String mn="";
		        String pas="";
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
		       
		ps=con.prepareStatement("select * from users_bank where username=? and password=?");
		           ps.setString(1,name);
		             ps.setString(2,pass); 
		           //System.out.println(user);
		           // System.out.println(pass);
		           rs=ps.executeQuery();
		          
		        CustomerBean bean=new CustomerBean();
		            if(rs.next())
		{
		        bean.setUsername(rs.getString("username"));
		            	bean.setEmail(rs.getString("email"));
		            	bean.setMobile(rs.getLong("mobile"));
		            	bean.setPassword(rs.getString("password"));
		            	bean.setAddress(rs.getString("address"));
		            	bean.setCity(rs.getString("city"));	
		            	bean.setState(rs.getString("state"));	
		            	bean.setCountry(rs.getString("country"));
		            	bean.setAccountnumber(rs.getString("accountnumber"));	
		            	bean.setAmount(rs.getInt("amount"));
		            	
		            	mn=rs.getString("username");
		            	pas=rs.getString("password");
		        
		
		            System.out.println("record found");
		if((mn.equals(name)) && (pas.equals(pass)))
		{
		        System.out.println("success");
		        
		        session.setAttribute("username",name);  
		        RequestDispatcher rd=request.getRequestDispatcher("Welcome.jsp");
		        rd.forward(request, response);
		       
		        //response.sendRedirect("Welcome.jsp");
		}
		else
		{
		    System.out.println("Create new account");  
		    response.sendRedirect("Signup.jsp");
		}
		        }
		      }
		        catch(Exception e)
		        {
		                        e.printStackTrace();
		        }
	}

}
