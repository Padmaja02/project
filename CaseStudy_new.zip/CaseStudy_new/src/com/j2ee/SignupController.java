package com.j2ee;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bank.bean.CustomerBean;

@WebServlet("/Welcome")
public class SignupController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    
    public SignupController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//PrintWriter out=response.getWriter();
		Connection con;
		PreparedStatement ps;
	      ResultSet rs;
	      String name=request.getParameter("t1");
			String eid=request.getParameter("t2");
			String mob=request.getParameter("t3");
			String pass=request.getParameter("t4");
			String add=request.getParameter("t6");
			String city=request.getParameter("t7");
			String state=request.getParameter("t8");
			String country=request.getParameter("t9");
			try{
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
				
				Statement s=con.createStatement();
                String sqlacc = "select count(*) from users_bank";
                rs = s.executeQuery(sqlacc);
                while (rs.next()) {
                      if (rs.getInt(1) == 0) {
                    	 
                             String year=Integer.toString(Calendar.getInstance().get(Calendar.YEAR));
                             String accno = "HDFC" + year + "00000001";
                             String query="insert into users_bank values(?,?,?,?,?,?,?,?,?,10000)";
             				
         					ps= con.prepareStatement(query);
         					ps.setString(1,name);
         					ps.setString(2,eid);
         					ps.setString(3,mob);
         					ps.setString(4,pass);
         					ps.setString(5,add);
         					ps.setString(6,city);
         					ps.setString(7,state);
         					ps.setString(8,country);
         					ps.setString(9,accno);
         					rs= ps.executeQuery();
         					if(rs.next())
         					{
         						HttpSession session=request.getSession(); 
         						session.setAttribute("username",name);
         						 
         		            RequestDispatcher rd1=request.getRequestDispatcher("Success.jsp");
         		                     rd1.include(request,response);
         		                    
         					}
                           
}
               
            else
                {
            	String maxno="";
                String maxaccno = "select substr(accountnumber,9) from users_bank order by substr(accountnumber,9) desc";
                rs = s.executeQuery(maxaccno);
               if(rs.next())
               {
            	   maxno=rs.getString(1);
               }
               //System.out.println(maxno);
				UserAccount ua=new UserAccount();
		            String accnum= ua.initialize(maxno);
				String query="insert into users_bank values(?,?,?,?,?,?,?,?,?,10000)";
				
					ps= con.prepareStatement(query);
					ps.setString(1,name);
					ps.setString(2,eid);
					ps.setString(3,mob);
					ps.setString(4,pass);
					ps.setString(5,add);
					ps.setString(6,city);
					ps.setString(7,state);
					ps.setString(8,country);
					ps.setString(9,accnum);
					 ps.executeQuery();
					 HttpSession session=request.getSession(); 
						session.setAttribute("username",name);
						
		            RequestDispatcher rd1=request.getRequestDispatcher("Success.jsp");
		                     rd1.include(request,response);
		                     
					System.out.println("Inserted");
                 
			}
			}
			}
			catch(Exception e){
				e.printStackTrace();
			}
	

}
}
