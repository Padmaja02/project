package com.bank.bean;

public class CustomerBean {
	private static String email;
	private static long mobile;
	public static String getPassword() {
		return password;
	}

	public static void setPassword(String password) {
		CustomerBean.password = password;
	}

	private static String password;
	private static String address;
	private static String city;
	private static String state;
	private static String country;
	private static String accountnumber;
	private static int amount;
	
	private static  String username;


	
	public static String getEmail() {
		return email;
	}

	public static void setEmail(String email) {
		CustomerBean.email = email;
	}

	public static long getMobile() {
		return mobile;
	}

	public static void setMobile(long mobile) {
		CustomerBean.mobile = mobile;
	}

	/*public static String getPassword() {
		return password;
	}

	public static void setPassword(String password) {
		CustomerBean.password = password;
	}*/

	public static String getAddress() {
		return address;
	}

	public static void setAddress(String address) {
		CustomerBean.address = address;
	}

	public static String getCity() {
		return city;
	}

	public static void setCity(String city) {
		CustomerBean.city = city;
	}

	public static String getState() {
		return state;
	}

	public static void setState(String state) {
		CustomerBean.state = state;
	}

	public static String getCountry() {
		return country;
	}

	public static void setCountry(String country) {
		CustomerBean.country = country;
	}

	public static String getAccountnumber() {
		return accountnumber;
	}

	public static void setAccountnumber(String accountnumber) {
		CustomerBean.accountnumber = accountnumber;
	}

	public static int getAmount() {
		return amount;
	}

	public static void setAmount(int amount) {
		CustomerBean.amount = amount;
	}

	
	public static String getUsername() {
		return username;
	}

	public static void setUsername(String username) {
		CustomerBean.username = username;
	}
}