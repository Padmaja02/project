package com.training.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;





import com.training.daoimpl.PatientJDBCTemplate;
import com.training.model.Patients;

@RestController
public class PatientController {

	@Autowired
	PatientJDBCTemplate patientDAOImpl;

	@RequestMapping("patientinsert/{id}/{name}/{age}")
    public void postPatient(@PathVariable("id")int id,@PathVariable("name")String name,@PathVariable("age")int age, Model model)
	{
		
	patientDAOImpl.postPatient(id, name, age);
alert("insert Successfully");
	System.out.println("insert successfully");
       
    }
	
	private void alert(String string) {
		// TODO Auto-generated method stub
		
	}

	@RequestMapping("patientupdate/{name}/{age}/{id}")
    public void updatePatient(@PathVariable("name")String name,@PathVariable("age")int age, @PathVariable("id")int id, Model model)
	{
		
	patientDAOImpl.updatePatient(name, age, id);

	System.out.println("update successfully");
       
    }
	
	
	@RequestMapping("patientdetails")
    public List<Patients> getAllPatients( Model model){
		List<Patients> patient = patientDAOImpl.getAllPatients();
        model.addAttribute("patients", patient);
      return patient;
    }
	
	
	
	@RequestMapping(value = "patientid/{id}", method = RequestMethod.GET)
	public @ResponseBody List<Patients> getPatient(@PathVariable("id") int id,HttpServletRequest request, HttpServletResponse response,	Model model) 
	{

		List<Patients> patient =patientDAOImpl.getPatient(id, request, response);
	
	return patient;
	
	}
	
	@RequestMapping("patientdelete/{id}")
    public void deletePatient(@PathVariable("id")int id, Model model)
	{
		
	patientDAOImpl.deletePatient(id);

	System.out.println("delete successfully");
       
    }
   
    }
